/**
 * Dữ liệu mẫu cho màn Xem kho – tháng 09/2026.
 * Khi tích hợp: thay KHO_DATA bằng dữ liệu từ API, giữ nguyên cấu trúc.
 *
 * Nhiên liệu (theo từng kho):
 *   opening      tồn đầu tháng (lít)
 *   capacity     sức chứa bồn (lít)      – thêm mới, để vẽ mức bồn
 *   safety       mức an toàn tối thiểu (lít) – thêm mới, để cảnh báo sắp hết
 *   moves        nhập / xuất / chuyển kho trong tháng
 *   pending      phiếu đề nghị xuất nhiên liệu chờ cấp
 *   declared     dầu đã khai trên phiếu xuất xe, chưa lập phiếu đề nghị
 *   parts        tồn phụ tùng đang nằm tại kho này (mã phụ tùng → số lượng)
 */
window.KHO_DATA = {
  month: '09/2026',
  daysInMonth: 30,

  regions: [
    { id: 'tb', name: 'Thà Bốc' },
    { id: 'tk', name: 'Thakhek' },
    { id: 'vc', name: 'Viêng Chăn' },
    { id: 'other', name: 'Khu vực khác' }
  ],

  warehouses: [
    {
      code: 'KHO-TB', region: 'tb', vi: 'Kho dầu Thà Bốc', lo: 'ສາງນ້ຳມັນ ທ່າບົກ',
      capacity: 10000, safety: 1000, avgCost: 31800, opening: 4370, yard: true,
      moves: [
        { date: '05/09/2026', type: 'out', qty: 600, doc: 'XK-2609-011', vehicle: '341', price: 31800 },
        { date: '12/09/2026', type: 'out', qty: 650, doc: 'XK-2609-017', vehicle: '342', price: 31800 },
        { date: '22/09/2026', type: 'transfer-out', qty: 400, doc: 'CK-2609-002', vehicle: '', price: 31800, to: 'KHO-TB-HL' }
      ],
      pending: [],
      declared: [
        { date: '24/09/2026', doc: 'PXX-2609-081', vehicle: '341', route: 'Thà Bốc – Kasi', qty: 450 },
        { date: '25/09/2026', doc: 'PXX-2609-084', vehicle: '345', route: 'Thà Bốc – Kasi', qty: 325 },
        { date: '27/09/2026', doc: 'PXX-2609-090', vehicle: '342', route: 'Thà Bốc – Viêng Chăn', qty: 500 },
        { date: '28/09/2026', doc: 'PXX-2609-093', vehicle: '341', route: 'Thà Bốc – Kasi', qty: 500 }
      ],
      parts: { NHOT: 40, BOTHANG: 3, LOP: 5, BAUHOI: 1, LOCDAU: 9 }
    },
    {
      code: 'KHO-TB-HL', region: 'tb', vi: 'Kho dầu sân Thà Bốc Huay Lek', lo: 'ສາງນ້ຳມັນ ສະໜາມທ່າບົກ ຫ້ວຍເລິກ',
      capacity: 5000, safety: 300, avgCost: 31800, opening: 0,
      moves: [
        { date: '22/09/2026', type: 'transfer-in', qty: 400, doc: 'CK-2609-002', vehicle: '', price: 31800, from: 'KHO-TB' }
      ],
      pending: [], declared: [], parts: {}
    },
    {
      code: 'KHO-KM28-TB', region: 'tb', vi: 'Kho dầu tuyến Km 28 Thà Bốc', lo: 'ສາງນ້ຳມັນ ເສັ້ນທາງຫຼັກ 28 ທ່າບົກ',
      capacity: 5000, safety: 300, avgCost: 0, opening: 0, moves: [], pending: [], declared: [], parts: {}
    },
    {
      code: 'KHO-TK', region: 'tk', vi: 'Kho dầu sân Thakhek', lo: 'ສາງນ້ຳມັນ ສະໜາມທ່າແຂກ',
      capacity: 5000, safety: 300, avgCost: 32100, opening: 0,
      moves: [
        { date: '10/09/2026', type: 'in', qty: 500, doc: 'NK-2609-004', vehicle: '', price: 32100 }
      ],
      pending: [], declared: [], parts: {}
    },
    {
      code: 'KHO-THAVAI', region: 'tk', vi: 'Kho dầu bản Thavai', lo: 'ສາງນ້ຳມັນ ບ້ານທະວາຍ',
      capacity: 3000, safety: 300, avgCost: 0, opening: 0, moves: [], pending: [], declared: [], parts: {}
    },
    {
      code: 'KHO-VC', region: 'vc', vi: 'Kho dầu Viêng Chăn', lo: 'ສາງນ້ຳມັນ ວຽງຈັນ',
      capacity: 15000, safety: 2000, avgCost: 31600, opening: 0,
      moves: [
        { date: '03/09/2026', type: 'in', qty: 3000, doc: 'NK-2609-001', vehicle: '', price: 31600 }
      ],
      pending: [], declared: [],
      parts: { NHOT: 20, BOTHANG: 2, LOP: 2, BAUHOI: 1, LOCDAU: 4 }
    },
    {
      code: 'KHO-KM28-VC', region: 'vc', vi: 'Kho dầu Km 28 Viêng Chăn', lo: 'ສາງນ້ຳມັນ ຫຼັກ 28 ວຽງຈັນ',
      capacity: 5000, safety: 300, avgCost: 0, opening: 0, moves: [], pending: [], declared: [], parts: {}
    },
    {
      code: 'KHO-PKX', region: 'other', vi: 'Kho dầu Pakxan', lo: 'ສາງນ້ຳມັນ ປາກຊັນ',
      capacity: 3000, safety: 300, avgCost: 0, opening: 0, moves: [], pending: [], declared: [], parts: {}
    }
  ],

  parts: [
    { code: 'NHOT', vi: 'Nhớt 15W-40', lo: 'ນ້ຳມັນເຄື່ອງ 15W-40', unit: 'lít', min: 40, cost: 85000 },
    { code: 'BOTHANG', vi: 'Bố thắng', lo: 'ຜ້າເບຣກ', unit: 'bộ', min: 2, cost: 950000 },
    { code: 'LOP', vi: 'Lốp 12R22.5', lo: 'ຢາງລົດ 12R22.5', unit: 'cái', min: 4, cost: 3257143 },
    { code: 'BAUHOI', vi: 'Bầu hơi', lo: 'ເຕົ້າລົມ', unit: 'cái', min: 2, cost: 500000 },
    { code: 'LOCDAU', vi: 'Lọc dầu', lo: 'ໄສ້ກອງນ້ຳມັນ', unit: 'cái', min: 4, cost: 176875 }
  ],

  // Nhập / xuất phụ tùng trong tháng (theo kho)
  partMoves: [
    { date: '08/09/2026', wh: 'KHO-TB', part: 'LOP', type: 'in', qty: 4, doc: 'NK-PT-2609-003' },
    { date: '14/09/2026', wh: 'KHO-TB', part: 'LOCDAU', type: 'in', qty: 6, doc: 'NK-PT-2609-005' },
    { date: '14/09/2026', wh: 'KHO-VC', part: 'LOCDAU', type: 'in', qty: 4, doc: 'NK-PT-2609-006' },
    { date: '19/09/2026', wh: 'KHO-TB', part: 'LOCDAU', type: 'out', qty: 3, doc: 'XK-PT-2609-009', vehicle: '341' }
  ],
  // Phụ tùng trên phiếu, chờ xuất kho
  partPending: [],

  // Hàng khách gửi ở bãi – gắn với bãi của kho
  cargo: [
    {
      code: 'QUANGSAT', vi: 'Quặng sắt', lo: 'ແຮ່ເຫຼັກ', unit: 'tấn', yard: 'KHO-TB',
      lots: [
        { doc: 'G4-0101-09/EPL', vehicle: '341', customer: 'ຄຳຕຸ້ຍ', origin: 'ກາສີ (ບ່ອນຂຸດແຮ່)', inQty: 42.3, left: 12.3, date: '15/09/2026' },
        { doc: 'G4-0102-09/EPL', vehicle: '342', customer: 'ຄຳຕຸ້ຍ', origin: 'ກາສີ (ບ່ອນຂຸດແຮ່)', inQty: 39.3, left: 14.3, date: '21/09/2026' },
        { doc: 'G4-0104-09/EPL', vehicle: '345', customer: 'ຄຳຕຸ້ຍ', origin: 'ກາສີ (ບ່ອນຂຸດແຮ່)', inQty: 41.5, left: 11.5, date: '29/09/2026' }
      ],
      moves: [
        { date: '15/09/2026', type: 'in', qty: 42.3, doc: 'G4-0101-09/EPL', vehicle: '341' },
        { date: '16/09/2026', type: 'out', qty: 30.0, doc: 'T4-0433-09/EPL', vehicle: '' },
        { date: '21/09/2026', type: 'in', qty: 39.3, doc: 'G4-0102-09/EPL', vehicle: '342' },
        { date: '23/09/2026', type: 'out', qty: 25.0, doc: 'T4-0445-09/EPL', vehicle: '' },
        { date: '29/09/2026', type: 'in', qty: 41.5, doc: 'G4-0104-09/EPL', vehicle: '345' },
        { date: '29/09/2026', type: 'out', qty: 30.0, doc: 'T4-0447-09/EPL', vehicle: '' }
      ]
    }
  ]
};
