/* global KHO_DATA */
(function () {
  'use strict';

  var D = KHO_DATA;
  var state = { view: 'all', tab: 'fuel', ovTab: 'fuel', filter: 'all', query: '', flashDoc: null };

  /* ================= Tiện ích ================= */
  function $(sel, root) { return (root || document).querySelector(sel); }
  function $$(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function esc(s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }
  var nf0 = new Intl.NumberFormat('en-US', { maximumFractionDigits: 0 });
  var nf2 = new Intl.NumberFormat('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  function n0(v) { return nf0.format(v || 0); }
  function n2(v) { return nf2.format(v || 0); }
  function dash(v, f) { return v ? (f || n0)(v) : '<span class="dash">–</span>'; }
  function day(d) { return parseInt(d.split('/')[0], 10); }
  function sum(list, f) { return list.reduce(function (s, x) { return s + (typeof f === 'function' ? f(x) : x[f]); }, 0); }
  function pct(a, b) { return b ? Math.max(0, Math.min(1, a / b)) : 0; }
  var uid = 0;

  /* ================= Tính toán ================= */
  var partByCode = {};
  D.parts.forEach(function (p) { partByCode[p.code] = p; });
  var whByCode = {};

  function calcWarehouse(w) {
    var inQ = sum(w.moves.filter(function (m) { return m.type === 'in' || m.type === 'transfer-in'; }), 'qty');
    var outQ = sum(w.moves.filter(function (m) { return m.type === 'out' || m.type === 'transfer-out'; }), 'qty');
    var stock = w.opening + inQ - outQ;
    var pending = sum(w.pending, 'qty');
    var declared = sum(w.declared, 'qty');
    var remain = stock - pending - declared;
    var status = stock <= 0 ? 'empty' : (remain < w.safety ? 'low' : 'ok');
    var alerts = [];
    if (status === 'low') alerts.push({ level: 'danger', text: 'Còn lại dưới mức an toàn' });
    if (declared > 0) alerts.push({ level: 'warn', text: n0(declared) + ' lít đã khai, chưa có đề nghị' });
    if (pending > 0) alerts.push({ level: 'warn', text: n0(pending) + ' lít chờ cấp' });
    var partKinds = Object.keys(w.parts || {}).filter(function (k) { return w.parts[k] > 0; }).length;
    var cargo = D.cargo.filter(function (c) { return c.yard === w.code; });
    return Object.assign(w, {
      inQ: inQ, outQ: outQ, stock: stock, pendingQty: pending, declaredQty: declared, remain: remain,
      status: status, alerts: alerts, partKinds: partKinds, cargoTypes: cargo
    });
  }
  D.warehouses.forEach(function (w) { calcWarehouse(w); whByCode[w.code] = w; });

  function partTotal(code) { return sum(D.warehouses, function (w) { return (w.parts && w.parts[code]) || 0; }); }
  function partMovesOf(code, wh) {
    return D.partMoves.filter(function (m) { return m.part === code && (!wh || m.wh === wh); });
  }
  function isBelowMin(p, qty) { return qty <= p.min; }

  var T = {
    stock: sum(D.warehouses, 'stock'),
    declared: sum(D.warehouses, 'declaredQty'),
    pending: sum(D.warehouses, 'pendingQty'),
    pendingDocs: sum(D.warehouses, function (w) { return w.pending.length; }),
    whCount: D.warehouses.length,
    empty: D.warehouses.filter(function (w) { return w.status === 'empty'; }),
    partsLow: D.parts.filter(function (p) { return isBelowMin(p, partTotal(p.code)); }),
    cargoTons: sum(D.cargo, function (c) { return sum(c.lots, 'left'); }),
    cargoLots: sum(D.cargo, function (c) { return c.lots.length; })
  };

  /* ================= Bồn chứa (SVG) ================= */
  function tankSvg(w, opts) {
    opts = opts || {};
    var id = 't' + (++uid);
    var W = opts.width || 84, H = opts.height || 150, pad = opts.scale ? 46 : 4;
    var bx = pad, bw = W - pad - 4, top = 10, bh = H - top - 6, r = Math.min(14, bw / 4);
    var cap = w.capacity || 1;
    var fillH = bh * pct(w.stock, cap);
    var declH = bh * pct(w.declaredQty + w.pendingQty, cap);
    var yFill = top + bh - fillH;
    var ySafe = top + bh - bh * pct(w.safety, cap);
    var wave = '';
    if (fillH > 6) {
      var y = yFill, x0 = bx, x1 = bx + bw, amp = Math.min(3, fillH / 6), seg = bw / 4;
      wave = 'M' + x0 + ',' + (y + amp) +
        ' Q' + (x0 + seg * 0.5) + ',' + (y - amp) + ' ' + (x0 + seg) + ',' + (y + amp) +
        ' T' + (x0 + seg * 2) + ',' + (y + amp) + ' T' + (x0 + seg * 3) + ',' + (y + amp) + ' T' + x1 + ',' + (y + amp) +
        ' L' + x1 + ',' + (top + bh) + ' L' + x0 + ',' + (top + bh) + ' Z';
    }
    var ticks = '';
    if (opts.scale) {
      [0, 0.25, 0.5, 0.75, 1].forEach(function (f) {
        var ty = top + bh - bh * f;
        ticks += '<line x1="' + (bx - 6) + '" x2="' + (bx - 2) + '" y1="' + ty + '" y2="' + ty + '" class="sv-line2"/>' +
          '<text x="' + (bx - 8) + '" y="' + (ty + 3.5) + '" text-anchor="end" font-size="10" class="sv-muted">' + n0(cap * f) + '</text>';
      });
    }
    var label = opts.label !== false && w.stock > 0
      ? '<text x="' + (bx + bw / 2) + '" y="' + Math.max(top + 16, yFill - 6) + '" text-anchor="middle" font-size="' + (opts.scale ? 15 : 12) +
        '" font-weight="700" class="' + (fillH > bh - 22 ? 'sv-onfill' : 'sv-ink') + '">' + Math.round(pct(w.stock, cap) * 100) + '%</text>'
      : '';
    return '<svg class="' + (opts.cls || '') + '" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="' +
      esc(w.vi + ': tồn ' + n0(w.stock) + ' trên ' + n0(cap) + ' lít') + '">' +
      '<defs><clipPath id="' + id + 'c"><rect x="' + bx + '" y="' + top + '" width="' + bw + '" height="' + bh + '" rx="' + r + '"/></clipPath>' +
      '<pattern id="' + id + 'h" width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">' +
      '<rect width="6" height="6" class="sv-warn-tint"/><rect width="3" height="6" class="sv-warn"/></pattern>' +
      '<linearGradient id="' + id + 'g" x1="0" x2="1"><stop offset="0" class="sv-stop1"/><stop offset=".55" class="sv-stop2"/><stop offset="1" class="sv-stop1"/></linearGradient></defs>' +
      ticks +
      '<rect x="' + bx + '" y="' + top + '" width="' + bw + '" height="' + bh + '" rx="' + r + '" class="sv-body" stroke-width="1.5"/>' +
      '<g clip-path="url(#' + id + 'c)">' +
        (wave ? '<path d="' + wave + '" fill="url(#' + id + 'g)"/>' : '') +
        (declH > 0 && fillH > 0 ? '<rect x="' + bx + '" y="' + yFill + '" width="' + bw + '" height="' + Math.min(declH, fillH) + '" fill="url(#' + id + 'h)" opacity=".92"/>' : '') +
      '</g>' +
      '<line x1="' + (bx + 2) + '" x2="' + (bx + bw - 2) + '" y1="' + ySafe + '" y2="' + ySafe + '" class="sv-safe" stroke-width="1.5" stroke-dasharray="4 3"/>' +
      '<rect x="' + (bx + bw / 2 - 9) + '" y="' + (top - 7) + '" width="18" height="7" rx="2" class="sv-cap"/>' +
      label + '</svg>';
  }

  function miniTank(w) {
    var H = 30, top = 4, fill = H * pct(w.stock, w.capacity), decl = H * pct(w.declaredQty + w.pendingQty, w.capacity);
    var col = w.status === 'low' ? 'sv-danger' : 'sv-fill';
    return '<svg class="mini-tank" viewBox="0 0 30 38" aria-hidden="true">' +
      '<rect x="6" y="' + top + '" width="18" height="' + H + '" rx="5" class="sv-body"/>' +
      (fill > 0 ? '<rect x="7" y="' + (top + H - fill) + '" width="16" height="' + fill + '" rx="4" class="' + col + '"/>' : '') +
      (decl > 0 && fill > 0 ? '<rect x="7" y="' + (top + H - fill) + '" width="16" height="' + Math.min(decl, fill) + '" class="sv-warn" opacity=".75"/>' : '') +
      '</svg>';
  }

  /* ================= Biểu đồ nhập / xuất trong tháng ================= */
  function flowSvg(w) {
    var days = D.daysInMonth, X0 = 46, X1 = 890, Y0 = 12, Y1 = 132, dx = (X1 - X0) / (days - 1);
    var perDay = [];
    for (var d = 1; d <= days; d++) perDay.push({ inQ: 0, outQ: 0, bal: 0 });
    w.moves.forEach(function (m) {
      var p = perDay[day(m.date) - 1];
      if (m.type === 'in' || m.type === 'transfer-in') p.inQ += m.qty; else p.outQ += m.qty;
    });
    var bal = w.opening;
    perDay.forEach(function (p) { bal += p.inQ - p.outQ; p.bal = bal; });
    var maxBal = Math.max(w.opening, Math.max.apply(null, perDay.map(function (p) { return p.bal; })), 1);
    var maxMv = Math.max(1, Math.max.apply(null, perDay.map(function (p) { return Math.max(p.inQ, p.outQ); })));
    var sy = function (v) { return Y1 - (v / maxBal) * (Y1 - Y0); };
    var bars = '', pts = [];
    perDay.forEach(function (p, i) {
      var x = X0 + i * dx;
      if (p.inQ) bars += '<rect x="' + (x - 5) + '" y="' + (Y1 - 44 * p.inQ / maxMv) + '" width="5" height="' + (44 * p.inQ / maxMv) + '" rx="1.5" class="sv-fill"><title>Ngày ' + (i + 1) + ': nhập ' + n0(p.inQ) + ' lít</title></rect>';
      if (p.outQ) bars += '<rect x="' + x + '" y="' + (Y1 - 44 * p.outQ / maxMv) + '" width="5" height="' + (44 * p.outQ / maxMv) + '" rx="1.5" class="sv-warn"><title>Ngày ' + (i + 1) + ': xuất ' + n0(p.outQ) + ' lít</title></rect>';
      pts.push(x.toFixed(1) + ',' + sy(p.bal).toFixed(1));
    });
    var axis = '';
    [1, 5, 10, 15, 20, 25, 30].forEach(function (dd) {
      var x = X0 + (dd - 1) * dx;
      axis += '<text x="' + x + '" y="' + (Y1 + 18) + '" text-anchor="middle" font-size="11" class="sv-muted">' + dd + '</text>';
    });
    var safeY = w.safety <= maxBal ? sy(w.safety) : null;
    return '<svg viewBox="0 0 900 156" preserveAspectRatio="none" role="img" aria-label="Tồn và nhập xuất theo ngày tháng ' + D.month + '">' +
      '<line x1="' + X0 + '" x2="' + X1 + '" y1="' + Y1 + '" y2="' + Y1 + '" class="sv-line2"/>' +
      '<line x1="' + X0 + '" x2="' + X1 + '" y1="' + Y0 + '" y2="' + Y0 + '" class="sv-grid"/>' +
      '<text x="' + (X0 - 8) + '" y="' + (Y0 + 4) + '" text-anchor="end" font-size="11" class="sv-muted">' + n0(maxBal) + '</text>' +
      '<text x="' + (X0 - 8) + '" y="' + (Y1 + 4) + '" text-anchor="end" font-size="11" class="sv-muted">0</text>' +
      (safeY !== null ? '<line x1="' + X0 + '" x2="' + X1 + '" y1="' + safeY + '" y2="' + safeY + '" class="sv-safe" stroke-dasharray="4 4" opacity=".7"/>' : '') +
      bars +
      '<polyline points="' + pts.join(' ') + '" fill="none" class="sv-bal" stroke-width="2" stroke-linejoin="round" vector-effect="non-scaling-stroke"/>' +
      axis + '</svg>';
  }

  /* ================= Danh sách kho (cột trái) ================= */
  function matchesFilter(w) {
    if (state.filter === 'alert') return w.alerts.length > 0 || w.parts && Object.keys(w.parts).some(function (k) { return isBelowMin(partByCode[k], partTotal(k)) && w.parts[k] > 0; });
    if (state.filter === 'stock') return w.stock > 0;
    if (state.filter === 'empty') return w.status === 'empty';
    return true;
  }
  function matchesQuery(w) {
    var q = state.query.trim().toLowerCase();
    if (!q) return true;
    return (w.vi + ' ' + w.lo + ' ' + w.code).toLowerCase().indexOf(q) >= 0;
  }

  function whTags(w) {
    var t = '';
    if (w.status === 'empty') t += '<span class="tag tag--empty">Trống</span>';
    if (w.status === 'low') t += '<span class="tag tag--danger">Dưới mức an toàn</span>';
    if (w.declaredQty) t += '<span class="tag tag--warn">Đã khai ' + n0(w.declaredQty) + '</span>';
    if (w.partKinds) t += '<span class="tag tag--ok">' + w.partKinds + ' phụ tùng</span>';
    if (w.cargoTypes.length) t += '<span class="tag tag--ok">Bãi hàng</span>';
    return t;
  }

  function renderList() {
    var html = '<li><button type="button" class="wh-item wh-all' + (state.view === 'all' ? ' is-active' : '') + '" data-open="all" role="option" aria-selected="' + (state.view === 'all') + '">' +
      '<span class="all-ico"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 10 12 4l9 6v10H3zM9 20v-6h6v6"/></svg></span>' +
      '<span><span class="wh-name">Toàn bộ kho</span><span class="wh-meta">' + T.whCount + ' kho nhiên liệu, phụ tùng và bãi hàng</span></span>' +
      '<span class="wh-qty">' + n0(T.stock) + '<small>lít</small></span></button></li>';
    var shown = 0;
    D.regions.forEach(function (r) {
      var list = D.warehouses.filter(function (w) { return w.region === r.id && matchesFilter(w) && matchesQuery(w); });
      if (!list.length) return;
      shown += list.length;
      html += '<li class="wh-group"><div class="wh-group-head"><span>' + esc(r.name) + '</span><span>' + n0(sum(list, 'stock')) + ' lít</span></div><ul class="wh-list">';
      list.forEach(function (w) {
        var active = state.view === w.code;
        html += '<li><button type="button" class="wh-item' + (active ? ' is-active' : '') + '" data-open="' + w.code + '" role="option" aria-selected="' + active + '">' +
          miniTank(w) +
          '<span><span class="wh-name">' + esc(w.vi) + '</span>' +
          '<span class="wh-meta"><span class="code">' + esc(w.code) + '</span>' + whTags(w) + '</span></span>' +
          '<span class="wh-qty">' + n0(w.stock) + '<small>/ ' + n0(w.capacity) + '</small></span></button></li>';
      });
      html += '</ul></li>';
    });
    if (!shown) html += '<li class="empty" style="margin-top:12px">Không có kho nào khớp bộ lọc. Chọn "Tất cả" để xem lại toàn bộ.</li>';
    $('#whList').innerHTML = html;
  }

  /* ================= Tìm theo số phiếu / số xe ================= */
  function allDocs() {
    var out = [];
    D.warehouses.forEach(function (w) {
      w.moves.forEach(function (m) { out.push({ wh: w.code, tab: 'fuel', doc: m.doc, vehicle: m.vehicle, text: moveLabel(m.type) + ' ' + n0(m.qty) + ' lít', date: m.date }); });
      w.declared.forEach(function (m) { out.push({ wh: w.code, tab: 'fuel', doc: m.doc, vehicle: m.vehicle, text: 'Đã khai ' + n0(m.qty) + ' lít', date: m.date }); });
      w.pending.forEach(function (m) { out.push({ wh: w.code, tab: 'fuel', doc: m.doc, vehicle: m.vehicle, text: 'Chờ cấp ' + n0(m.qty) + ' lít', date: m.date }); });
    });
    D.partMoves.forEach(function (m) { out.push({ wh: m.wh, tab: 'parts', doc: m.doc, vehicle: m.vehicle, text: partByCode[m.part].vi + ' ' + (m.type === 'in' ? 'nhập ' : 'xuất ') + n2(m.qty), date: m.date }); });
    D.cargo.forEach(function (c) {
      c.moves.forEach(function (m) { out.push({ wh: c.yard, tab: 'cargo', doc: m.doc, vehicle: m.vehicle, text: c.vi + ' ' + (m.type === 'in' ? 'nhập ' : 'xuất ') + n2(m.qty) + ' tấn', date: m.date }); });
    });
    return out;
  }
  var DOCS = allDocs();

  function renderSearchResults() {
    var q = state.query.trim().toLowerCase(), box = $('#searchResults');
    if (q.length < 2) { box.hidden = true; return; }
    var hits = DOCS.filter(function (d) { return (d.doc + ' ' + (d.vehicle ? 'xe ' + d.vehicle : '')).toLowerCase().indexOf(q) >= 0; }).slice(0, 8);
    var partHits = D.parts.filter(function (p) { return (p.vi + ' ' + p.lo).toLowerCase().indexOf(q) >= 0; });
    var cargoHits = D.cargo.filter(function (c) { return (c.vi + ' ' + c.lo).toLowerCase().indexOf(q) >= 0; });
    if (!hits.length && !partHits.length && !cargoHits.length) { box.hidden = true; return; }
    var html = '';
    if (hits.length) {
      html += '<h3>Phiếu và số xe</h3>' + hits.map(function (d) {
        return '<button type="button" class="sr-item" data-open="' + d.wh + '" data-tab="' + d.tab + '" data-doc="' + esc(d.doc) + '"><span class="code">' + esc(d.doc) + '</span>' +
          '<span>' + esc(d.text) + (d.vehicle ? ', xe ' + esc(d.vehicle) : '') + '</span><small>' + esc(whByCode[d.wh].vi) + ', ' + esc(d.date) + '</small></button>';
      }).join('');
    }
    if (partHits.length) {
      html += '<h3>Phụ tùng</h3>' + partHits.map(function (p) {
        var wh = D.warehouses.filter(function (w) { return w.parts[p.code] > 0; });
        return '<button type="button" class="sr-item" data-open="' + (wh[0] ? wh[0].code : 'all') + '" data-tab="parts"><span class="code">' + esc(p.code) + '</span>' +
          '<span>' + esc(p.vi) + ' <span class="lo muted">' + esc(p.lo) + '</span></span><small>Có ở ' + wh.length + ' kho, tổng ' + n2(partTotal(p.code)) + ' ' + esc(p.unit) + '</small></button>';
      }).join('');
    }
    if (cargoHits.length) {
      html += '<h3>Hàng gửi bãi</h3>' + cargoHits.map(function (c) {
        return '<button type="button" class="sr-item" data-open="' + c.yard + '" data-tab="cargo"><span class="code">' + esc(c.code) + '</span>' +
          '<span>' + esc(c.vi) + '</span><small>Bãi ' + esc(whByCode[c.yard].vi) + '</small></button>';
      }).join('');
    }
    box.innerHTML = html; box.hidden = false;
  }

  /* ================= Tổng quan toàn bộ kho ================= */
  function renderAll() {
    var sentence = '<b>' + n0(T.stock) + ' lít</b> nhiên liệu đang nằm ở ' + (T.whCount - T.empty.length) + ' trên ' + T.whCount + ' kho. ' +
      (T.declared ? '<span class="warn">' + n0(T.declared) + ' lít</span> đã khai trên phiếu xuất xe nhưng chưa có đề nghị. ' : '') +
      (T.pending ? n0(T.pending) + ' lít chờ cấp theo ' + T.pendingDocs + ' phiếu. ' : 'Không có phiếu đề nghị nào chờ cấp. ') +
      (T.empty.length ? T.empty.length + ' kho đang trống.' : '');

    var tanks = D.regions.map(function (r) {
      return D.warehouses.filter(function (w) { return w.region === r.id; }).map(function (w) {
        return '<button type="button" class="tank-card' + (w.status === 'empty' ? ' is-empty' : '') + '" data-open="' + w.code + '">' +
          tankSvg(w) +
          '<span class="t-name">' + esc(w.vi.replace(/^Kho dầu /, '')) + '</span>' +
          '<span class="t-qty"><b>' + n0(w.stock) + '</b> / ' + n0(w.capacity) + ' L</span>' +
          (w.status === 'low' ? '<span class="tag tag--danger">Dưới mức</span>' : w.declaredQty ? '<span class="tag tag--warn">Đã khai ' + n0(w.declaredQty) + '</span>' : '') +
          '</button>';
      }).join('');
    }).join('');

    // Ma trận phụ tùng × kho
    var partWh = D.warehouses.filter(function (w) { return w.partKinds > 0; });
    var mHead = '<tr><th>Phụ tùng</th><th>ĐVT</th>' + partWh.map(function (w) { return '<th class="num">' + esc(w.vi.replace(/^Kho dầu /, '')) + '</th>'; }).join('') +
      '<th class="num">Tổng</th><th class="num">Tối thiểu</th><th class="num">Giá vốn BQ</th></tr>';
    var mBody = D.parts.map(function (p) {
      var tot = partTotal(p.code), low = isBelowMin(p, tot);
      return '<tr class="is-clickable" data-open="' + (partWh[0] ? partWh[0].code : 'all') + '" data-tab="parts"><td><b>' + esc(p.vi) + '</b><span class="sub lo">' + esc(p.lo) + '</span></td><td>' + esc(p.unit) + '</td>' +
        partWh.map(function (w) {
          var q = w.parts[p.code] || 0;
          return '<td class="cell ' + (q ? (low ? 'cell-low' : 'cell-ok') : 'cell-none') + '"><span>' + (q ? n2(q) : '–') + '</span></td>';
        }).join('') +
        '<td class="num"><b class="' + (low ? 'below' : '') + '">' + n2(tot) + '</b>' + (low ? '<span class="sub below">Dưới mức</span>' : '') + '</td>' +
        '<td class="num">' + n2(p.min) + '</td><td class="num">' + n0(p.cost) + '</td></tr>';
    }).join('');

    // Hàng khách gửi ở bãi
    var cargoRows = D.cargo.map(function (c) {
      return c.lots.map(function (l) {
        var leftP = pct(l.left, l.inQty) * 100;
        return '<tr class="is-clickable" data-open="' + c.yard + '" data-tab="cargo"><td><span class="code">' + esc(l.doc) + '</span><span class="sub">Xe ' + esc(l.vehicle) + '</span></td>' +
          '<td>' + esc(c.vi) + '<span class="sub lo">' + esc(c.lo) + '</span></td><td class="lo">' + esc(l.customer) + '</td>' +
          '<td>' + esc(whByCode[c.yard].vi.replace(/^Kho dầu /, 'Bãi ')) + '</td>' +
          '<td style="min-width:150px"><div class="lot-bar" title="Còn ' + n2(l.left) + ' / nhập ' + n2(l.inQty) + ' tấn"><span class="left" style="width:' + leftP + '%"></span><span class="gone" style="width:' + (100 - leftP) + '%"></span></div></td>' +
          '<td class="num"><b>' + n2(l.left) + '</b><span class="sub">/ ' + n2(l.inQty) + '</span></td><td>' + esc(l.date) + '</td></tr>';
      }).join('');
    }).join('');

    // Cần xử lý
    var todos = [];
    D.warehouses.forEach(function (w) {
      if (w.status === 'low') todos.push({ lvl: 'danger', wh: w.code, tab: 'fuel', title: w.vi + ': còn lại ' + n0(w.remain) + ' lít', sub: 'Thấp hơn mức an toàn ' + n0(w.safety) + ' lít sau khi trừ dầu đã khai' });
      if (w.declaredQty) todos.push({ lvl: 'warn', wh: w.code, tab: 'fuel', title: n0(w.declaredQty) + ' lít đã khai, chưa có đề nghị', sub: w.vi + ', ' + w.declared.length + ' phiếu xuất xe' });
    });
    T.partsLow.forEach(function (p) {
      var wh = D.warehouses.filter(function (w) { return w.parts[p.code] > 0; });
      todos.push({ lvl: 'danger', wh: wh[0] ? wh[0].code : 'all', tab: 'parts', title: p.vi + ': còn ' + n2(partTotal(p.code)) + ' ' + p.unit, sub: 'Bằng hoặc dưới mức tối thiểu ' + n2(p.min) + ', có ở ' + wh.map(function (w) { return w.vi.replace(/^Kho dầu /, ''); }).join(', ') });
    });
    if (T.empty.length) todos.push({ lvl: 'muted', wh: T.empty[0].code, tab: 'fuel', title: T.empty.length + ' kho đang trống', sub: T.empty.map(function (w) { return w.vi.replace(/^Kho dầu /, ''); }).join(', ') });

    var ovTabs = [
      { id: 'fuel', label: 'Nhiên liệu', count: T.whCount + ' kho' },
      { id: 'parts', label: 'Phụ tùng', count: D.parts.length + ' món' },
      { id: 'cargo', label: 'Hàng gửi bãi', count: T.cargoLots + ' lô' }
    ];
    var ovBody;
    if (state.ovTab === 'parts') {
      ovBody = '<div class="panel-body"><p class="tab-intro">Số lượng từng món đang nằm ở kho nào. Ô đỏ là món đã chạm mức tối thiểu. Bấm một dòng để xem kho.</p>' +
        '<div class="tbl-wrap"><table class="tbl matrix"><thead>' + mHead + '</thead><tbody>' + mBody + '</tbody></table></div></div>';
    } else if (state.ovTab === 'cargo') {
      ovBody = '<div class="panel-body"><p class="tab-intro">' + n2(T.cargoTons) + ' tấn còn ở bãi, ' + T.cargoLots + ' lô. Thanh xanh là phần còn lại của từng lô.</p>' +
        '<div class="tbl-wrap"><table class="tbl"><thead><tr><th>Số phiếu</th><th>Loại hàng</th><th>Khách hàng</th><th>Bãi</th><th>Còn / nhập</th><th class="num">Còn (tấn)</th><th>Ngày nhập</th></tr></thead><tbody>' + cargoRows + '</tbody></table></div></div>';
    } else {
      ovBody = '<div class="panel-body"><div class="tab-intro-row"><p class="summary-line">' + sentence + '</p>' +
        '<div class="legend"><span><i class="lg-fill"></i>Tồn</span><span><i class="lg-decl"></i>Đã khai hoặc chờ cấp</span><span><i class="lg-safe"></i>Mức an toàn</span></div></div>' +
        '<div class="tank-wall">' + tanks + '</div></div>';
    }

    $('#work').innerHTML =
      '<section class="panel ov-todo"><div class="ov-todo-head"><h2>Cần xử lý</h2><p>' + todos.length + ' việc bên kho cần để ý trong tháng ' + D.month + '</p></div>' +
        '<ul class="todo">' + todos.map(function (t) {
          return '<li><button type="button" data-open="' + t.wh + '" data-tab="' + t.tab + '"><span class="dot dot--' + t.lvl + '"></span>' +
            '<span><strong>' + esc(t.title) + '</strong><small>' + esc(t.sub) + '</small></span>' +
            '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" class="sv-chev" stroke-width="1.8" aria-hidden="true"><path d="m9 6 6 6-6 6"/></svg></button></li>';
        }).join('') + '</ul></section>' +
      '<section class="panel ov-main">' +
        '<div class="tabs" role="tablist" aria-label="Toàn bộ kho">' + ovTabs.map(function (t) {
          return '<button type="button" class="tab" role="tab" data-ovtab="' + t.id + '" aria-selected="' + (state.ovTab === t.id) + '">' +
            t.label + ' <span class="count">' + t.count + '</span></button>';
        }).join('') + '</div>' +
        '<div role="tabpanel">' + ovBody + '</div>' +
      '</section>';
  }

  /* ================= Chi tiết một kho ================= */
  function moveLabel(t) {
    return { 'in': 'Nhập kho', 'out': 'Xuất kho', 'transfer-in': 'Chuyển đến', 'transfer-out': 'Chuyển đi' }[t] || t;
  }
  function moveTag(t) {
    var cls = t === 'in' ? 'mv--in' : t === 'out' ? 'mv--out' : 'mv--tr';
    return '<span class="mv ' + cls + '">' + moveLabel(t) + '</span>';
  }
  function flashCls(doc) { return state.flashDoc && doc === state.flashDoc ? ' is-flash' : ''; }

  function fuelTab(w) {
    var pend = w.pending.length
      ? '<div class="tbl-wrap"><table class="tbl"><thead><tr><th>Ngày</th><th>Số phiếu</th><th>Số xe</th><th class="num">Số lít</th></tr></thead><tbody>' +
        w.pending.map(function (p) { return '<tr class="' + flashCls(p.doc) + '"><td>' + esc(p.date) + '</td><td class="code">' + esc(p.doc) + '</td><td>' + esc(p.vehicle) + '</td><td class="num">' + n0(p.qty) + '</td></tr>'; }).join('') +
        '</tbody></table></div>'
      : '<div class="empty">Không có phiếu đề nghị nào chờ cấp ở kho này.</div>';
    var decl = w.declared.length
      ? '<div class="tbl-wrap"><table class="tbl"><thead><tr><th>Ngày</th><th>Phiếu xuất xe</th><th>Số xe</th><th>Tuyến</th><th class="num">Số lít</th></tr></thead><tbody>' +
        w.declared.map(function (p) { return '<tr class="' + flashCls(p.doc) + '"><td>' + esc(p.date) + '</td><td class="code">' + esc(p.doc) + '</td><td>' + esc(p.vehicle) + '</td><td>' + esc(p.route) + '</td><td class="num warn-txt">' + n0(p.qty) + '</td></tr>'; }).join('') +
        '</tbody><tfoot><tr><td colspan="4">Cộng</td><td class="num">' + n0(w.declaredQty) + '</td></tr></tfoot></table></div>'
      : '<div class="empty">Không có dầu đã khai mà chưa lập phiếu đề nghị.</div>';
    var bal = w.opening;
    var ledger = '<tr><td>01/' + D.month + '</td><td><span class="muted">Tồn đầu tháng</span></td><td></td><td></td><td class="num"></td><td class="num"></td><td class="num"><b>' + n0(w.opening) + '</b></td><td class="num"></td></tr>' +
      w.moves.slice().sort(function (a, b) { return day(a.date) - day(b.date); }).map(function (m) {
        var isIn = m.type === 'in' || m.type === 'transfer-in';
        bal += isIn ? m.qty : -m.qty;
        var other = m.to ? 'Đến ' + esc(whByCode[m.to].vi) : m.from ? 'Từ ' + esc(whByCode[m.from].vi) : (m.vehicle ? 'Xe ' + esc(m.vehicle) : '<span class="dash">–</span>');
        return '<tr class="' + flashCls(m.doc) + '"><td>' + esc(m.date) + '</td><td>' + moveTag(m.type) + '</td><td class="code">' + esc(m.doc) + '</td><td>' + other + '</td>' +
          '<td class="num">' + (isIn ? n0(m.qty) : '<span class="dash">–</span>') + '</td><td class="num">' + (!isIn ? n0(m.qty) : '<span class="dash">–</span>') + '</td>' +
          '<td class="num"><b>' + n0(bal) + '</b></td><td class="num">' + (m.price ? n0(m.price) : '') + '</td></tr>';
      }).join('');
    return '<div class="block"><h3>Phiếu đề nghị xuất nhiên liệu chờ cấp <span class="count">' + w.pending.length + '</span></h3>' + pend + '</div>' +
      '<div class="block"><h3>Dầu đã khai trên phiếu xuất xe, chưa lập phiếu đề nghị <span class="count">' + w.declared.length + '</span></h3>' + decl + '</div>' +
      '<div class="block"><h3>Sổ kho tháng ' + D.month + ' <span class="count">' + w.moves.length + '</span></h3>' +
      '<div class="tbl-wrap"><table class="tbl"><thead><tr><th>Ngày</th><th>Loại</th><th>Số phiếu</th><th>Xe / kho đối ứng</th><th class="num">Nhập (L)</th><th class="num">Xuất (L)</th><th class="num">Tồn sau (L)</th><th class="num">Đơn giá (LAK)</th></tr></thead><tbody>' +
      ledger + '</tbody><tfoot><tr><td colspan="4">Cộng tháng</td><td class="num">' + n0(w.inQ) + '</td><td class="num">' + n0(w.outQ) + '</td><td class="num">' + n0(w.stock) + '</td><td></td></tr></tfoot></table></div></div>';
  }

  function partsTab(w) {
    var codes = Object.keys(w.parts).filter(function (k) { return w.parts[k] > 0; });
    if (!codes.length) return '<div class="empty">Kho này không giữ phụ tùng. Phụ tùng đang nằm ở: ' +
      D.warehouses.filter(function (x) { return x.partKinds; }).map(function (x) { return '<button type="button" class="link" data-open="' + x.code + '" data-tab="parts">' + esc(x.vi) + '</button>'; }).join(', ') + '.</div>';
    var rows = codes.map(function (k) {
      var p = partByCode[k], q = w.parts[k], tot = partTotal(k), low = isBelowMin(p, tot);
      var mv = partMovesOf(k, w.code);
      var inQ = sum(mv.filter(function (m) { return m.type === 'in'; }), 'qty'), outQ = sum(mv.filter(function (m) { return m.type === 'out'; }), 'qty');
      var scale = Math.max(tot, p.min * 2, 1);
      return '<tr><td><b>' + esc(p.vi) + '</b><span class="sub lo">' + esc(p.lo) + '</span></td><td>' + esc(p.unit) + '</td>' +
        '<td class="num"><b>' + n2(q) + '</b></td>' +
        '<td style="min-width:170px"><div class="bar" title="Tổng ' + n2(tot) + ', tối thiểu ' + n2(p.min) + '"><i class="' + (low ? 'is-low' : '') + '" style="width:' + (pct(tot, scale) * 100) + '%"></i><span class="min-mark" style="left:' + (pct(p.min, scale) * 100) + '%"></span></div>' +
        '<span class="sub ' + (low ? 'below' : '') + '">Tổng ' + n2(tot) + ' / tối thiểu ' + n2(p.min) + (low ? ', dưới mức' : '') + '</span></td>' +
        '<td class="num">' + dash(inQ, n2) + '</td><td class="num">' + dash(outQ, n2) + '</td>' +
        '<td class="num">' + n0(p.cost) + '</td><td class="num">' + n0(q * p.cost) + '</td></tr>';
    }).join('');
    var value = sum(codes, function (k) { return w.parts[k] * partByCode[k].cost; });
    var mvRows = D.partMoves.filter(function (m) { return m.wh === w.code; }).map(function (m) {
      return '<tr class="' + flashCls(m.doc) + '"><td>' + esc(m.date) + '</td><td>' + moveTag(m.type) + '</td><td>' + esc(partByCode[m.part].vi) + '</td><td class="code">' + esc(m.doc) + '</td><td>' + (m.vehicle ? esc(m.vehicle) : '<span class="dash">–</span>') + '</td><td class="num">' + n2(m.qty) + '</td></tr>';
    }).join('');
    return '<div class="block"><h3>Phụ tùng tại kho <span class="count">' + codes.length + '</span></h3>' +
      '<div class="tbl-wrap"><table class="tbl"><thead><tr><th>Phụ tùng</th><th>ĐVT</th><th class="num">Tồn tại kho</th><th>Toàn hệ thống so với tối thiểu</th><th class="num">Nhập tháng</th><th class="num">Xuất tháng</th><th class="num">Giá vốn BQ</th><th class="num">Giá trị tồn (LAK)</th></tr></thead><tbody>' +
      rows + '</tbody><tfoot><tr><td colspan="7">Giá trị phụ tùng tại kho</td><td class="num">' + n0(value) + '</td></tr></tfoot></table></div></div>' +
      '<div class="block"><h3>Phụ tùng trên phiếu, chờ xuất kho <span class="count">' + D.partPending.filter(function (x) { return x.wh === w.code; }).length + '</span></h3><div class="empty">Không có phụ tùng nào đang chờ xuất ở kho này.</div></div>' +
      '<div class="block"><h3>Nhập / xuất phụ tùng trong tháng <span class="count">' + D.partMoves.filter(function (m) { return m.wh === w.code; }).length + '</span></h3>' +
      (mvRows ? '<div class="tbl-wrap"><table class="tbl"><thead><tr><th>Ngày</th><th>Loại</th><th>Phụ tùng</th><th>Số phiếu</th><th>Số xe</th><th class="num">Số lượng</th></tr></thead><tbody>' + mvRows + '</tbody></table></div>' : '<div class="empty">Chưa có nhập xuất phụ tùng trong tháng.</div>') + '</div>';
  }

  function cargoTab(w) {
    if (!w.cargoTypes.length) return '<div class="empty">Kho này không có bãi nhận hàng khách gửi.</div>';
    return w.cargoTypes.map(function (c) {
      var left = sum(c.lots, 'left'), inQ = sum(c.moves.filter(function (m) { return m.type === 'in'; }), 'qty'), outQ = sum(c.moves.filter(function (m) { return m.type === 'out'; }), 'qty');
      var lots = c.lots.map(function (l) {
        var p = pct(l.left, l.inQty) * 100;
        return '<tr class="' + flashCls(l.doc) + '"><td><span class="code">' + esc(l.doc) + '</span><span class="sub">Xe ' + esc(l.vehicle) + '</span></td><td class="lo">' + esc(l.customer) + '</td><td class="lo">' + esc(l.origin) + '</td>' +
          '<td style="min-width:150px"><div class="lot-bar"><span class="left" style="width:' + p + '%"></span><span class="gone" style="width:' + (100 - p) + '%"></span></div></td>' +
          '<td class="num">' + n2(l.inQty) + '</td><td class="num"><b>' + n2(l.left) + '</b></td><td>' + esc(l.date) + '</td></tr>';
      }).join('');
      var mv = c.moves.slice().sort(function (a, b) { return day(b.date) - day(a.date); }).map(function (m) {
        return '<tr class="' + flashCls(m.doc) + '"><td>' + esc(m.date) + '</td><td>' + moveTag(m.type) + '</td><td class="code">' + esc(m.doc) + '</td><td>' + (m.vehicle ? esc(m.vehicle) : '<span class="dash">–</span>') + '</td><td class="num">' + n2(m.qty) + '</td></tr>';
      }).join('');
      return '<div class="block"><h3>' + esc(c.vi) + ' <span class="lo muted" style="font-weight:500">' + esc(c.lo) + '</span></h3>' +
        '<div class="fuel-stats" style="grid-template-columns:repeat(3,minmax(0,1fr));margin-bottom:14px">' +
        '<div class="is-main"><span>Còn ở bãi</span><b>' + n2(left) + ' <small>tấn</small></b></div>' +
        '<div><span>Nhập trong tháng</span><b>' + n2(inQ) + ' <small>tấn</small></b></div>' +
        '<div style="border-right:0"><span>Xuất trong tháng</span><b>' + n2(outQ) + ' <small>tấn</small></b></div></div>' +
        '<h3>Các lô còn hàng <span class="count">' + c.lots.length + '</span></h3>' +
        '<div class="tbl-wrap"><table class="tbl"><thead><tr><th>Số phiếu</th><th>Khách hàng</th><th>Nơi bốc</th><th>Còn / nhập</th><th class="num">Nhập (tấn)</th><th class="num">Còn (tấn)</th><th>Ngày</th></tr></thead><tbody>' + lots + '</tbody></table></div></div>' +
        '<div class="block"><h3>Nhập / xuất gần đây <span class="count">' + c.moves.length + '</span></h3>' +
        '<div class="tbl-wrap"><table class="tbl"><thead><tr><th>Ngày</th><th>Loại</th><th>Số phiếu</th><th>Số xe</th><th class="num">Số lượng (tấn)</th></tr></thead><tbody>' + mv + '</tbody></table></div></div>';
    }).join('');
  }

  function renderWarehouse(w) {
    var tabs = [
      { id: 'fuel', label: 'Nhiên liệu', count: w.moves.length + w.declared.length + w.pending.length },
      { id: 'parts', label: 'Phụ tùng', count: w.partKinds },
      { id: 'cargo', label: 'Hàng gửi bãi', count: sum(w.cargoTypes, function (c) { return c.lots.length; }) }
    ];
    if (!tabs.some(function (t) { return t.id === state.tab; })) state.tab = 'fuel';
    var body = state.tab === 'parts' ? partsTab(w) : state.tab === 'cargo' ? cargoTab(w) : fuelTab(w);
    var lastIn = w.moves.filter(function (m) { return m.type === 'in' || m.type === 'transfer-in'; }).slice(-1)[0];
    var remainCls = w.remain < w.safety && w.stock > 0 ? 'is-danger' : '';

    $('#work').innerHTML =
      '<section class="panel">' +
        '<div class="wh-head"><div>' +
          '<h2>' + esc(w.vi) + '</h2><p class="lo-name">' + esc(w.lo) + ' <span class="tag tag--la">LA</span></p>' +
          '<div class="facts">' +
            '<span>Mã kho<b class="code" style="font-size:14px">' + esc(w.code) + '</b></span>' +
            '<span>Khu vực<b>' + esc(D.regions.filter(function (r) { return r.id === w.region; })[0].name) + '</b></span>' +
            '<span>Sức chứa<b>' + n0(w.capacity) + ' lít</b></span>' +
            '<span>Mức an toàn<b>' + n0(w.safety) + ' lít</b></span>' +
            '<span>Giá vốn bình quân<b>' + (w.avgCost ? n0(w.avgCost) + ' LAK/lít' : '–') + '</b></span>' +
            '<span>Nhập gần nhất<b>' + (lastIn ? esc(lastIn.date) : '–') + '</b></span>' +
          '</div></div>' +
          '<div class="wh-head-tools"><button type="button" class="btn btn--ghost" data-open="all">' +
          '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m15 6-6 6 6 6"/></svg>Toàn bộ kho</button></div>' +
        '</div>' +
        '<div class="fuel-hero">' + tankSvg(w, { width: 190, height: 250, scale: true, cls: 'big-tank' }) +
          '<div class="fuel-stats">' +
            '<div><span>Tồn cuối tháng</span><b>' + n0(w.stock) + ' <small>lít</small></b><p>Đầu tháng ' + n0(w.opening) + ', nhập ' + n0(w.inQ) + ', xuất ' + n0(w.outQ) + '</p></div>' +
            '<div class="' + (w.pendingQty ? 'is-warn' : '') + '"><span>Chờ cấp theo đề nghị</span><b>' + n0(w.pendingQty) + ' <small>lít</small></b><p>' + w.pending.length + ' phiếu đề nghị</p></div>' +
            '<div class="' + (w.declaredQty ? 'is-warn' : '') + '"><span>Đã khai, chưa có đề nghị</span><b>' + n0(w.declaredQty) + ' <small>lít</small></b><p>' + w.declared.length + ' phiếu xuất xe</p></div>' +
            '<div class="is-main ' + remainCls + '"><span>Còn lại có thể cấp</span><b>' + n0(w.remain) + ' <small>lít</small></b><p>' +
              (w.stock <= 0 ? 'Kho đang trống' : w.remain < w.safety ? 'Thấp hơn mức an toàn ' + n0(w.safety) + ' lít' : 'Trên mức an toàn ' + n0(w.remain - w.safety) + ' lít') + '</p></div>' +
          '</div></div>' +
        '<div class="flow"><div class="flow-head"><h3>Tồn và nhập xuất theo ngày, tháng ' + D.month + '</h3>' +
          '<div class="legend"><span><i class="lg-bal"></i>Tồn</span><span><i class="lg-in"></i>Nhập</span><span><i class="lg-out"></i>Xuất</span><span><i class="lg-safe"></i>Mức an toàn</span></div></div>' +
          flowSvg(w) + '</div>' +
      '</section>' +
      '<section class="panel">' +
        '<div class="tabs" role="tablist" aria-label="Nội dung kho">' + tabs.map(function (t) {
          return '<button type="button" class="tab" role="tab" data-tab-go="' + t.id + '" aria-selected="' + (state.tab === t.id) + '">' + t.label + ' <span class="count">' + t.count + '</span></button>';
        }).join('') + '</div>' +
        '<div class="tab-panel" role="tabpanel">' + body + '</div>' +
      '</section>';
  }

  /* ================= Điều hướng ================= */
  function render() {
    renderList();
    renderSearchResults();
    var w = whByCode[state.view];
    if (w) {
      renderWarehouse(w);
      $('#pageSub').textContent = w.vi + ', tháng ' + D.month + '. Màn này chỉ để xem.';
    } else {
      state.view = 'all';
      renderAll();
      $('#pageSub').textContent = 'Theo dõi tồn từng kho, tháng ' + D.month + '. Màn này chỉ để xem.';
    }
    var flash = $('.is-flash');
    if (flash) flash.scrollIntoView({ block: 'center', behavior: 'smooth' });
    state.flashDoc = null;
  }

  function open(view, tab, doc) {
    state.view = view || 'all';
    if (tab) state.tab = tab;
    state.flashDoc = doc || null;
    var hash = state.view === 'all' ? '' : '#kho=' + encodeURIComponent(state.view) + '&tab=' + state.tab;
    if (location.hash !== hash) history.replaceState(null, '', location.pathname + location.search + hash);
    render();
    if (window.innerWidth <= 1180) $('#work').scrollIntoView({ block: 'start' });
  }

  function readHash() {
    var m = /kho=([^&]+)(?:&tab=(\w+))?/.exec(location.hash);
    if (m) { state.view = decodeURIComponent(m[1]); if (m[2]) state.tab = m[2]; }
  }

  /* ================= Xuất Excel (CSV) / PDF ================= */
  function downloadCsv(name, rows) {
    var csv = rows.map(function (r) {
      return r.map(function (c) { c = String(c == null ? '' : c); return /[",\n]/.test(c) ? '"' + c.replace(/"/g, '""') + '"' : c; }).join(',');
    }).join('\r\n');
    var data = '\uFEFF' + csv;   // BOM để Excel đọc đúng tiếng Việt / tiếng Lào
    if (DOWNLOADS) {              // đang mở trong trình xem Claude: dùng hộp lưu file của trình xem
      DOWNLOADS.save({ filename: name, data: data }).catch(function () {});
      return;
    }
    var blob = new Blob([data], { type: 'text/csv;charset=utf-8' });
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 0);
  }
  function exportCurrent() {
    var w = whByCode[state.view], m = D.month.replace('/', '-');
    if (!w) {
      var rows = [['Mã kho', 'Tên kho', 'Tên Lào', 'Khu vực', 'Sức chứa (L)', 'Tồn đầu (L)', 'Nhập (L)', 'Xuất (L)', 'Tồn (L)', 'Chờ cấp (L)', 'Đã khai chưa đề nghị (L)', 'Còn lại (L)', 'Mức an toàn (L)']];
      D.warehouses.forEach(function (x) {
        rows.push([x.code, x.vi, x.lo, D.regions.filter(function (r) { return r.id === x.region; })[0].name, x.capacity, x.opening, x.inQ, x.outQ, x.stock, x.pendingQty, x.declaredQty, x.remain, x.safety]);
      });
      rows.push([]); rows.push(['Phụ tùng', 'ĐVT'].concat(D.warehouses.filter(function (x) { return x.partKinds; }).map(function (x) { return x.code; })).concat(['Tổng', 'Tối thiểu']));
      D.parts.forEach(function (p) {
        rows.push([p.vi, p.unit].concat(D.warehouses.filter(function (x) { return x.partKinds; }).map(function (x) { return x.parts[p.code] || 0; })).concat([partTotal(p.code), p.min]));
      });
      return downloadCsv('ton-kho-' + m + '.csv', rows);
    }
    var r2 = [['Kho', w.code, w.vi], ['Tháng', D.month], [], ['Ngày', 'Loại', 'Số phiếu', 'Xe / kho đối ứng', 'Nhập (L)', 'Xuất (L)', 'Tồn sau (L)', 'Đơn giá (LAK)'], ['01/' + D.month, 'Tồn đầu tháng', '', '', '', '', w.opening, '']];
    var bal = w.opening;
    w.moves.slice().sort(function (a, b) { return day(a.date) - day(b.date); }).forEach(function (mv) {
      var isIn = mv.type === 'in' || mv.type === 'transfer-in'; bal += isIn ? mv.qty : -mv.qty;
      r2.push([mv.date, moveLabel(mv.type), mv.doc, mv.to || mv.from || mv.vehicle || '', isIn ? mv.qty : '', isIn ? '' : mv.qty, bal, mv.price || '']);
    });
    r2.push([]); r2.push(['Đã khai chưa đề nghị']); r2.push(['Ngày', 'Phiếu xuất xe', 'Số xe', 'Tuyến', 'Số lít']);
    w.declared.forEach(function (d) { r2.push([d.date, d.doc, d.vehicle, d.route, d.qty]); });
    downloadCsv(w.code + '-' + m + '.csv', r2);
  }

  /* ================= Sự kiện ================= */
  document.addEventListener('click', function (e) {
    var t = e.target.closest('[data-open]');
    if (t) { open(t.getAttribute('data-open'), t.getAttribute('data-tab'), t.getAttribute('data-doc')); return; }
    var ov = e.target.closest('[data-ovtab]');
    if (ov) { state.ovTab = ov.getAttribute('data-ovtab'); renderAll(); var ob = $('[data-ovtab="' + state.ovTab + '"]'); if (ob) ob.focus(); return; }
    var tab = e.target.closest('[data-tab-go]');
    if (tab) { state.tab = tab.getAttribute('data-tab-go'); open(state.view, state.tab); var btn = $('[data-tab-go="' + state.tab + '"]'); if (btn) btn.focus(); }
  });
  $('#filters').addEventListener('click', function (e) {
    var c = e.target.closest('[data-filter]'); if (!c) return;
    state.filter = c.getAttribute('data-filter');
    $$('#filters .chip').forEach(function (x) { x.classList.toggle('is-on', x === c); });
    renderList();
  });
  $('#search').addEventListener('input', function (e) { state.query = e.target.value; renderList(); renderSearchResults(); });
  document.addEventListener('keydown', function (e) {
    if (e.key === '/' && document.activeElement.tagName !== 'INPUT') { e.preventDefault(); $('#search').focus(); }
    if (e.key === 'Escape' && document.activeElement === $('#search')) { $('#search').value = ''; state.query = ''; renderList(); renderSearchResults(); }
    if ((e.key === 'ArrowDown' || e.key === 'ArrowUp') && e.target.closest && e.target.closest('#whList')) {
      var items = $$('#whList .wh-item'), i = items.indexOf(e.target.closest('.wh-item'));
      var next = items[i + (e.key === 'ArrowDown' ? 1 : -1)];
      if (next) { e.preventDefault(); next.focus(); }
    }
    if ((e.key === 'ArrowRight' || e.key === 'ArrowLeft') && e.target.getAttribute && e.target.getAttribute('role') === 'tab') {
      var tabs = $$('[role="tab"]'), j = tabs.indexOf(e.target), nt = tabs[(j + (e.key === 'ArrowRight' ? 1 : tabs.length - 1)) % tabs.length];
      nt.click();
    }
  });
  $('#btnExcel').addEventListener('click', exportCurrent);
  $('#btnPdf').addEventListener('click', function () { window.print(); });
  window.addEventListener('hashchange', function () { readHash(); render(); });

  // Khi trang được mở trong trình xem Claude, tải file qua capability "downloads" (null = không có, dùng cách thường)
  var DOWNLOADS = null;
  if (window.claude && typeof window.claude.use === 'function') {
    window.claude.use('downloads').then(function (d) { DOWNLOADS = d; }).catch(function () {});
  }

  readHash();
  render();
})();
